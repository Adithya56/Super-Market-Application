package purchaseAndSales;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PurchaseDetails")
public class PurchaseDeatils extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String s1 = request.getParameter("pname");
		String s2 = request.getParameter("productid");
		String s3 = request.getParameter("batchno");
		String s4 = request.getParameter("qty");
		// int qt = (Integer.parseInt(s4));

		String s5 = request.getParameter("pcost");

		try {
			PrintWriter pw = response.getWriter();
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection(
					"jdbc:postgresql://192.168.110.48:5432/plf_training?user=plf_training_admin&password=pff123");
			PreparedStatement st = conn.prepareStatement(
					"insert into PurchaseDetails (prod_name,prod_id,batchno,qty,prod_cost) values(?,?,?,?,?)");

			st.setString(1, s1);
			st.setInt(2, (Integer.parseInt(s2)));
			st.setInt(3, (Integer.parseInt(s3)));
			st.setInt(4, (Integer.parseInt(s4)));
			st.setDouble(5, (Double.parseDouble(s5)));
			int x = st.executeUpdate();
			ResultSet rs = st.executeQuery("select prod_id,batchno,prod_name,qty,prod_cost from PurchaseDetails ");
			System.out.println("inserted successfully");
			while (rs.next()) {
				if (rs.getInt(1) == (Integer.parseInt(s1)) && (rs.getInt(2) == (Integer.parseInt(s3)))) {
					PreparedStatement stt = conn.prepareStatement("update table sm_stock set stock+=?");
					stt.setInt(4, (Integer.parseInt(s4)));
					int c = stt.executeUpdate();
					pw.println("<br>Updated Succesfully");
				} else {
					PreparedStatement stt = conn.prepareStatement("insert into sm_stock values(?,?,?,?,?,?)");
					stt.setInt(1, rs.getInt(1));
					stt.setInt(2, rs.getInt(2));
					stt.setString(3, rs.getString(3));
					stt.setInt(4,rs.getInt(4));
					stt.setDouble(5,rs.getDouble(5));
					stt.setDouble(6,)
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
