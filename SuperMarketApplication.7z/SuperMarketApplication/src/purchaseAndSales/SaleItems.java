package purchaseAndSales;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SaleItems
 */
@WebServlet("/SaleItems")
public class SaleItems extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		int productId = Integer.valueOf(request.getParameter("prodId"));
		int batchNo = Integer.valueOf(request.getParameter("batchNo"));
		int quantity = Integer.valueOf(request.getParameter("qty"));
		double salePrice = 0.0;
		int curr_stock = 0;
		boolean stock = false;
		boolean product = false;
		try {
			Class.forName("org.postgresql.Driver");

			Connection conn = DriverManager.getConnection(
					"jdbc:postgresql://192.168.110.48:5432/plf_training?user=plf_training_admin&password=pff123");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from sm_stock");
			while (rs.next()) {
				if (rs.getInt(1) == productId && rs.getInt(2) == batchNo) {
					product = true;
					if (rs.getInt(4) >= quantity) {
						stock = true;
						salePrice = rs.getDouble(6);
						curr_stock = rs.getInt(4);
					}
					break;
				}
			}
			if (!product)
				pw.write("<h2>product not available</h2>");
			else if (!stock)
				pw.write("<h2>Stock not available</h2>");
			else if (stock && product) {
				PreparedStatement ps = conn
						.prepareStatement("insert into SalesDetails (prod_id,batchno,qty,sale_cost) values (?,?,?,?)");
				ps.setInt(1, productId);
				ps.setInt(2, batchNo);
				ps.setInt(3, quantity);
				ps.setDouble(4, salePrice);
				int count = ps.executeUpdate();
				pw.write("<h3>SaleDetails : </h3>" + count);
				ps = conn.prepareStatement("update sm_stock set stock = (?) where prod_id = (?) and batchno = (?)");
				ps.setInt(1, (curr_stock - quantity));
				ps.setInt(2, productId);
				ps.setInt(3, batchNo);
				count = ps.executeUpdate();
				pw.write("<h3>StockDetails : </h3>" + count);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
