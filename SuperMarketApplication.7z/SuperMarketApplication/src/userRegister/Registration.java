package userRegister;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			PrintWriter pw = response.getWriter();
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection(
					"jdbc:postgresql://192.168.110.48:5432/plf_training?user=plf_training_admin&password=pff123");
			PreparedStatement st = null;
			String type = request.getParameter("type");
			String uname = request.getParameter("uname");
			String pass = request.getParameter("password");
			String name = request.getParameter("name");

			if (type.equals("customer"))
				st = conn.prepareStatement("select cId from sm_customerdetails");
			else
				st = conn.prepareStatement("select oId from sm_ownerdetails");
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				if (rs.getString(1).equals(uname)) {
					pw.println("<h2 style='color:red'>Username already exists</h2>");
					return;
				}
			}
			if (type.equals("customer"))
				st = conn.prepareStatement("insert into sm_customerdetails values(?,?,?)");
			else
				st = conn.prepareStatement("insert into sm_ownerdetails values(?,?,?)");

			st.setString(1, name);
			st.setString(2, uname);
			st.setString(3, pass);

			st.executeUpdate();
			pw.println("<script>Window.prompt('Updated')</script>");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
